package com.crwncastl.ui.tests;

import org.testng.annotations.DataProvider;

public class CheckersFiveMovesData {

	@DataProvider(name="checkersData")
	public Object[] dataMethod() 
	{
		return new Object[]  {	"42,53|51,42|22,33|11,22|22,04",
								"02,13|11,02|00,11|42,24|62,73",
								"22,13|11,22|22,33|13,04|02,24"
							};
	}
}
