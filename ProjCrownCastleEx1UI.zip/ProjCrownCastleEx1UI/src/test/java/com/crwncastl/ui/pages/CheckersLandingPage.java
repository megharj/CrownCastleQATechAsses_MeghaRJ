package com.crwncastl.ui.pages;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Wait;
import org.testng.Assert;

import com.crwncastl.ui.tests.CheckersTestBase;


public class CheckersLandingPage {
	public WebDriver driver;
	public static final String CHECKERS_EXPECTED_TITLE ="Checkers - Games for the Brain";
	
	public CheckersLandingPage() {
		super();	
		this.driver = CheckersTestBase.driver;
	}
	
//Locators
	String  hdrLandingPgXPath = "//h1[text()='Checkers']";
	String  aRefRestartXPath = "//p/a[text()='Restart...']";
	String  pNextMovMsgXPath = "//p[@id='message']";
	String  pStartMsgXPath = "//p[@id='message' and text()='Select an orange piece to move.']";
	String  imgSrcXPath = "//img[@src='you1.gif' and @name='space<<space_num>>']";
	String  imgDestXPath = "//img[contains(@src,'gray.gif') and @name='space<<space_num>>']";

//Methods	
	public boolean ConfirmSiteUp() {
		boolean isSiteUp = false; 
		try {
			String actTitle = driver.getTitle();	
			WebElement hdrLandingPgElem =  driver.findElement(By.xpath(hdrLandingPgXPath));
			if(actTitle.equals(CHECKERS_EXPECTED_TITLE) && hdrLandingPgElem.isDisplayed())
				isSiteUp = true;
		}
		catch(Exception exp)
		{
			System.out.println("ConfirmSiteUp:Exception: "+ exp.getMessage());			
		}		
		return isSiteUp;		
	}
	
	public void MovePawn(String src, String dest) {		
		try 
		{
			Thread.sleep(3000);
			String srcXPath = imgSrcXPath.replace("<<space_num>>", src);
			String destXPath = imgDestXPath.replace("<<space_num>>", dest);
			List<WebElement> srcElems = driver.findElements(By.xpath(srcXPath));
			List<WebElement> destElems = driver.findElements(By.xpath(destXPath));
			if(!(srcElems.size() == 1 && destElems.size() == 1)){
				Assert.fail("Wrong move provided!!! Move: ("+src+","+dest+")");
			}
			srcElems.get(0).click();
			destElems.get(0).click();
		}
		catch(Exception exp)
		{
			System.out.println("MovePawn:Exception: "+ exp.getMessage());			
		}
	}
	
	public void WaitforNextMove() {		
		try 
		{
			Wait<WebDriver> wait = new FluentWait<WebDriver>(driver)
					  .withTimeout(Duration.ofSeconds(60))
					  .pollingEvery(Duration.ofSeconds(10))
					  .ignoring(NoSuchElementException.class);			
			wait.until(ExpectedConditions.textToBePresentInElementLocated(By.xpath(pNextMovMsgXPath), "Make a move."));			
		}
		catch(Exception exp)
		{
			System.out.println("WaitforNextMove:Exception: "+ exp.getMessage());			
		}
	}
	
	public void PlayPredCheckers(int moveCount, String movesData) {		
		try 
		{
			String[] moves = movesData.split("\\|");
			int actualMoveCount = moves.length;
			if(actualMoveCount < moveCount) {
				Assert.fail("Wrong number of moves provided!!! Actual: "+ actualMoveCount+ "; Expected: "+moveCount);
			}
			
			String src, dest;
			String[] moveSrcDest = new String[2];
			for(int i =0; i< moveCount;i++)
			{
				moveSrcDest = moves[i].split("\\,");				
				src = moveSrcDest[0];
				dest= moveSrcDest[1];
				MovePawn(src,dest);
				WaitforNextMove();
			}
		}
		catch(Exception exp)
		{
			System.out.println("WaitforNextMove:Exception: "+ exp.getMessage());			
		}
	}
	
	public void RestartCheckers() {
		try 
		{
			driver.findElement(By.xpath(aRefRestartXPath)).click();
		}
		catch(Exception exp)
		{
			System.out.println("RestartCheckers:Exception: "+ exp.getMessage());			
		}
	}
	
	public boolean VerifyRestartSuccess() {
		boolean success = false;
		try 
		{
			success = driver.findElement(By.xpath(pStartMsgXPath)).isDisplayed();
		}
		catch(Exception exp)
		{
			System.out.println("VerifyRestartSuccess:Exception: "+ exp.getMessage());			
		}
		return success;
	}
}
