package com.crwncastl.ui.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.crwncastl.ui.tests.CardGameTestBase;

public class CardGameLandingPage {
	
	public WebDriver driver;
	public static final String CARD_GAME_EXPECTED_TITLE ="Deck of Cards API";
	
	public CardGameLandingPage() {
		super();	
		driver = CardGameTestBase.driver;
	}
	
//Locators


//Methods	
	public boolean ConfirmSiteUp() {
		boolean isSiteUp = false; 
		try {
			String actTitle = driver.getTitle();	
			WebElement hdrLandingPgElem =  driver.findElement(By.xpath("//h1[text()='Deck of Cards']"));
			if(actTitle.equals(CARD_GAME_EXPECTED_TITLE) && hdrLandingPgElem.isDisplayed())
				isSiteUp = true;
		}
		catch(Exception exp)
		{
			//TODO: exception handling feature impl
			System.out.println("ConfirmSiteUp:Exception: "+ exp.getMessage());			
		}		
		return isSiteUp;		
	}
}
