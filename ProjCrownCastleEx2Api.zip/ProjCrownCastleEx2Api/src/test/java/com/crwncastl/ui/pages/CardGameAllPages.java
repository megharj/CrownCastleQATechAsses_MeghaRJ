package com.crwncastl.ui.pages;


public class CardGameAllPages {
	
	//CardGameLandingPage
	public static CardGameLandingPage CardGameLandingPage() {
		return new CardGameLandingPage();
	}
}
