package com.crwncastl.api.endpoints;

import static io.restassured.RestAssured.*;
import io.restassured.response.Response;

public class DeckOfCardEndPoints {

	public static Response GetNewDeck(){
		Response res = given()
					//.log().all()	
					.when()
					.get(Routes.brand_new_deck_url);
		
		return res;
	}
	
	public static Response Reshuffle(String deck_id) {
		Response res = given()
					//.log().all()
					.pathParam("deck_id", deck_id)
					.when()
					.get(Routes.reshuffle_cards_url);
			
		return res;
	}
	
	public static Response DealCards(String deck_id, int count_num) {
		
		Response res = given()
					//.log().all()
					.when()
					.pathParam("count_num", Integer.toString(count_num))
					.pathParam("deck_id", deck_id)					
					.get(Routes.draw_card_url);
		
		return res;
	}
	
	public static Response CreateShuffleNDraw(int count_num){
		Response res = given()
				//.log().all()
				.when()
				.pathParam("count_num", count_num)
				.get(Routes.new_deck_shuffle_draw_url);
	
		return res;
	}
}
