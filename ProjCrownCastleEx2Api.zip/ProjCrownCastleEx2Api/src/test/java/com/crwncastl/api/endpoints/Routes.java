package com.crwncastl.api.endpoints;

public class Routes {

	// URLs
	public static String base_url = "https://deckofcardsapi.com/api/deck";
	public static String brand_new_deck_url = base_url+"/new/";
	public static String reshuffle_cards_url = base_url+ "/{deck_id}/shuffle/?remaining=true";//shuffles remaining cards
	public static String draw_card_url =base_url +"/{deck_id}/draw/?count={count_num}";
	public static String new_deck_shuffle_draw_url =base_url +"/new/draw/?count={count_num}";

}
