package com.crwncastl.api.tests;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.crwncastl.api.endpoints.DeckOfCardEndPoints;
import com.crwncastl.ui.pages.CardGameAllPages;
import com.crwncastl.ui.tests.CardGameTestBase;

import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;

public class VerifyCardGame extends CardGameTestBase{

	public static int DealCount = 3;
	public static int DeckCountWithoutJoker = 52;
	public static ArrayList<String> ListOf10sCards = new ArrayList<String>(Arrays.asList("JACK", "QUEEN", "KING"));
	public static String responseTextAce ="ACE";
	public static int BlackJack = 21;
	
	@Test
	public void testBlackJack_StepByStep() {
		
		//confirm site up
		Assert.assertTrue(CardGameAllPages.CardGameLandingPage().ConfirmSiteUp(), "The Site is NOT up!!! No more steps executed.");
		
		//Get a new deck and retrieve deck id for next steps
		String DeckId;
		Response res = DeckOfCardEndPoints.GetNewDeck();
		int statCode= res.getStatusCode();
		Assert.assertEquals(statCode, 200, "Failed GetNewDeck! Status code: "+statCode);
		JsonPath jsonPath = new JsonPath(res.getBody().asPrettyString());
		boolean res_success = jsonPath.getBoolean("success");
		Assert.assertTrue(res_success, "Failed GetNewDeck! Response success: "+ res_success);
		DeckId = jsonPath.getString("deck_id");
		Assert.assertNotNull(DeckId, "Failed GetNewDeck! deck_id: "+ DeckId);
		int cardsRemaining = jsonPath.getInt("remaining");
		Assert.assertEquals(cardsRemaining, DeckCountWithoutJoker, "Failed GetNewDeck! Cards remaining: "+cardsRemaining);
		
		//Shuffle the deck
		res = null;
		jsonPath = null;
		res = DeckOfCardEndPoints.Reshuffle(DeckId);
		statCode= res.getStatusCode();
		Assert.assertEquals(statCode, 200, "Failed Reshuffle! Status code: "+statCode);
		jsonPath = new JsonPath(res.getBody().asPrettyString());
		res_success = jsonPath.getBoolean("success");
		Assert.assertTrue(res_success, "Failed Reshuffle! Response success: "+ res_success);
		cardsRemaining = jsonPath.getInt("remaining");
		Assert.assertEquals(cardsRemaining, DeckCountWithoutJoker, "Failed Reshuffle! Cards remaining: "+cardsRemaining);
		
		//Deal 3 cards - player 1
		res = null;
		jsonPath = null;
		res = DeckOfCardEndPoints.DealCards(DeckId, DealCount);
		statCode= res.getStatusCode();
		Assert.assertEquals(statCode, 200, "Failed DealCards, Player1! Status code: "+statCode);
		String resBodyP1 = res.getBody().asPrettyString();
		System.out.println("Response body, DealCards, Player1: " + resBodyP1);
		jsonPath = new JsonPath(resBodyP1);
		cardsRemaining = jsonPath.getInt("remaining");
		int iDeckCountAfterDeal = DeckCountWithoutJoker - DealCount;
		Assert.assertEquals(cardsRemaining, iDeckCountAfterDeal, "Failed DealCards, Player1! Cards remaining after deal: "+cardsRemaining);
		ArrayList<String> cardsPlayer1= GetCardsForPlayer(jsonPath);

		//Deal 3 cards - player 2
		res = null;
		jsonPath = null;
		res = DeckOfCardEndPoints.DealCards(DeckId, DealCount);
		statCode= res.getStatusCode();
		Assert.assertEquals(statCode, 200, "Failed DealCards, Player2! Status code: "+statCode);
		String resBodyP2 = res.getBody().asPrettyString();
		System.out.println("Response body, DealCards, Player2: " + resBodyP2);
		jsonPath = new JsonPath(resBodyP2);
		cardsRemaining = jsonPath.getInt("remaining");
		iDeckCountAfterDeal = iDeckCountAfterDeal - DealCount;
		Assert.assertEquals(cardsRemaining, iDeckCountAfterDeal, "Failed DealCards, Player2! Cards remaining after deal: "+cardsRemaining);
		List<String> cardsPlayer2 = GetCardsForPlayer(jsonPath);
		
		//verify any player blackjack
		if(CheckForBlackJack(cardsPlayer1))
			System.out.println("YES! Player 1 has BlackJack");
		if(CheckForBlackJack(cardsPlayer2))
			System.out.println("Yes! Player 2 has BlackJack");
		
	}
	
	@Test
	public void testBlackJack_AllInOneCall() {
		
		//CreateShuffleNDraw - player 1
		String DeckId;
		Response res = DeckOfCardEndPoints.CreateShuffleNDraw(DealCount);
		int statCode= res.getStatusCode();
		Assert.assertEquals(statCode, 200, "Failed CreateShuffleNDraw! Status code: "+statCode);
		String resBodyP1 = res.getBody().asPrettyString();
		System.out.println("Response body, DealCards, Player 1: " + resBodyP1);
		JsonPath jsonPath = new JsonPath(resBodyP1);
		boolean res_success = jsonPath.getBoolean("success");
		Assert.assertTrue(res_success, "Failed CreateShuffleNDraw! Response success: "+ res_success);
		DeckId = jsonPath.getString("deck_id");
		Assert.assertNotNull(DeckId, "Failed CreateShuffleNDraw! deck_id: "+ DeckId);
		int cardsRemaining = jsonPath.getInt("remaining");
		int iDeckCountAfterDeal = DeckCountWithoutJoker - DealCount;
		Assert.assertEquals(cardsRemaining, iDeckCountAfterDeal, "Failed CreateShuffleNDraw, Player1! Cards remaining after deal: "+cardsRemaining);
		ArrayList<String> cardsPlayer1= GetCardsForPlayer(jsonPath);
		
		//Deal 3 cards - player 2
		res = null;
		jsonPath = null;
		res = DeckOfCardEndPoints.DealCards(DeckId, DealCount);
		statCode= res.getStatusCode();
		Assert.assertEquals(statCode, 200, "Failed DealCards, Player2! Status code: "+statCode);
		String resBodyP2 = res.getBody().asPrettyString();
		System.out.println("Response body, DealCards, Player2: " + resBodyP2);
		jsonPath = new JsonPath(resBodyP2);
		cardsRemaining = jsonPath.getInt("remaining");
		iDeckCountAfterDeal = iDeckCountAfterDeal - DealCount;
		Assert.assertEquals(cardsRemaining, iDeckCountAfterDeal, "Failed DealCards, Player2! Cards remaining after deal: "+cardsRemaining);
		List<String> cardsPlayer2 = GetCardsForPlayer(jsonPath);
		
		//verify any player blackjack
		if(CheckForBlackJack(cardsPlayer1))
			System.out.println("YES! Player 1 has BlackJack");
		if(CheckForBlackJack(cardsPlayer2))
			System.out.println("Yes! Player 2 has BlackJack");
	}
	
//Helper
	private ArrayList<String> GetCardsForPlayer (JsonPath jsonPath) {
		ArrayList<String> cardsPlayer1= new ArrayList<String>(DealCount);
		for(int i =0; i< DealCount; i++)
		{
			String cardVal = jsonPath.getString("cards["+i+"].value");
			if(ListOf10sCards.contains(cardVal))
				cardVal = "10";
			cardsPlayer1.add(cardVal);
		}
		return cardsPlayer1;
	}
	
	private boolean CheckForBlackJack(List<String> player) {
		boolean blckJack = false;
		int cardTotal = 0;
		int countAce = Collections.frequency(player, responseTextAce);
		if(countAce == 0)
		{
			for(int i =0; i< DealCount; i++)
				cardTotal += Integer.parseInt(player.get(i));
			
			if (cardTotal == 21)
				blckJack = true;
		}
		else if(countAce == 1)
		{
			player.remove(String.valueOf(responseTextAce));
			for(int i =0; i< DealCount-1; i++)
				cardTotal += Integer.parseInt(player.get(i));
			
			if(cardTotal+11==21 || cardTotal+1==21)
				blckJack = true;
		}
		else if(countAce == 2)
		{
			player.removeAll(Collections.singleton(responseTextAce));
			if(Integer.parseInt(player.get(0))+ 2 == 21 || Integer.parseInt(player.get(0))+ 12 == 21)
				blckJack = true;
		}
//		if(! (countAce == 2))
//			System.out.println("Player Total: "+ cardTotal + "; With ACES count: "+ countAce);
		return blckJack;
	}
}
