package com.crwncastl.ui.pages;

public class CheckersAllPages {
	
	//CheckersLandingPage
	public static CheckersLandingPage CheckersLandingPage() {
		return new CheckersLandingPage();
	}
}
