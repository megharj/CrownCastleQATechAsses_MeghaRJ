package com.crwncastl.ui.tests;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;

import io.github.bonigarcia.wdm.WebDriverManager;

public class CheckersTestBase {
	public static WebDriver driver = null;	
	public static final String CHECKERS_APP_URL ="https://www.gamesforthebrain.com/game/checkers/";
	
	@BeforeClass
	public void SetUpTest() {
		WebDriverManager.chromedriver().setup();		
		ChromeOptions options = new ChromeOptions();
		options.addArguments("--remote-allow-origins=*");
		DesiredCapabilities cp = new DesiredCapabilities();
		cp.setCapability(ChromeOptions.CAPABILITY, options);
		options.merge(cp);
		driver = new ChromeDriver(options);
		driver.manage().window().maximize();
		driver.get(CHECKERS_APP_URL);
	}
	
	@AfterClass
	public void TearDownTest() {
		driver.quit();	
		driver = null;		
	}	
}
