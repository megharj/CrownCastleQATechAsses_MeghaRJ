package com.crwncastl.ui.tests;

import org.testng.annotations.DataProvider;

public class CheckersFiveMovesData {

	@DataProvider(name="checkersData")
	public Object[] dataMethod() 
	{
		return new Object[]  {	
				
								"42,53|51,42|22,33|11,22|22,04",// valid ...
								"02,13|11,02|00,11|42,24|62,73",
								"22,13|11,22|22,33|13,04|02,24"
							};
	}
	
	@DataProvider(name="checkersData_Invalid")
	public Object[] dataMethod2() 
	{
		return new Object[]  {	
								"42,42|51,42|22,33|11,22|22,04", //same src and destination
								"51,42|51,42|22,33|11,22|22,04", //invalid scr in first move 
								"42,43|51,42|22,33|11,22|22,04", //invalid move - horizontal
								"42,32|51,42|22,33|11,22|22,04", //invalid move - vertical
								"42,53|51,42|22,105|11,22|22,04", //invalid move 
								"0,0|51,42|22,33|11,22|22,04", // invalid src and destination
								"42,53|51,42|22,33|11,22", // invalid number of moves
								"42|51|22,33|11,22|22,04",// missing src/dest for first move
								"42,53|51,42|22,33|11,22|22",// missing src/dest for a later move
								"42,53|51,42|22,33|11,22|XX,67", // invalid data(non integer) in src/dest
								"|||", //empty moves
								""// empty data
							};
	}
	
}
