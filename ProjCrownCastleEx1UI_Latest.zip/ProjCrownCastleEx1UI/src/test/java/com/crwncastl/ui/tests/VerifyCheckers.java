package com.crwncastl.ui.tests;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.crwncastl.ui.pages.CheckersAllPages;

public class VerifyCheckers extends CheckersTestBase{
	
	@Test(dataProvider = "checkersData", dataProviderClass=CheckersFiveMovesData.class)
	public void testCheckersFiveMoves(String data) {
		try {
			//confirm site up
			Assert.assertTrue(CheckersAllPages.CheckersLandingPage().ConfirmSiteUp(), "The Site is NOT up!!! No more steps executed.");
			
			//make 5 legal moves with a blue taken
			CheckersAllPages.CheckersLandingPage().PlayPredCheckers(5, data);		
		}
		catch(Exception exp) {
			// handle exception
		}
		finally {
			//restart and confirm
			CheckersAllPages.CheckersLandingPage().RestartCheckers();
			Assert.assertTrue(CheckersAllPages.CheckersLandingPage().VerifyRestartSuccess(),"The game NOT restared on Restart Click");
		}
	}
	
	@Test(dataProvider = "checkersData_Invalid", dataProviderClass=CheckersFiveMovesData.class)
	public void testCheckersFiveMoves_Invalid(String data) {
		try {
		
			//confirm site up
			Assert.assertTrue(CheckersAllPages.CheckersLandingPage().ConfirmSiteUp(), "The Site is NOT up!!! No more steps executed.");
			
			//make 5 legal moves with a blue taken
			CheckersAllPages.CheckersLandingPage().PlayPredCheckers(5, data);
		}
		catch(Exception exp) {
			// handle exception
		}
		finally {
			//restart and confirm
			CheckersAllPages.CheckersLandingPage().RestartCheckers();
			Assert.assertTrue(CheckersAllPages.CheckersLandingPage().VerifyRestartSuccess(),"The game NOT restared on Restart Click");
		}
	}
}
